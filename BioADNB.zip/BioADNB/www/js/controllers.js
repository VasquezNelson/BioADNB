angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope) {})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  }
  /* co-created with Rémi -> https://github.com/strowbeary
 thank you */

  class SineCanvas{
      constructor() {
          this.canvas = document.querySelector('canvas');
          this.ctx = this.canvas.getContext('2d');
          this.drawers = [];

          this.addEventListener();
      }

      update() {
          this.ctx.clearRect(0,0,this.canvas.width, this.canvas.height);
          for (let child of this.drawers) {
              child.update();
          }
          requestAnimationFrame(() => this.update())
      }

      onResize() {
          this.canvas.width = window.innerWidth = 600;
          this.canvas.height = window.innerHeight;
          for (let drawer of this.drawers) (
              drawer.init()
          )
      }

      addChild(child) {
          this.drawers.push(child);
          this.onResize();
          this.update();
      }

      addEventListener() {
          window.addEventListener('resize', () => this.onResize());
      }
  }

  class SineWave {
      constructor(options, canvas) {
          this.options = {
              pointSpacing: 10,
              amplitude: 55,
              lineNumber: 6,
              particuleAlpha: 0.8,
              dx: 0.20, //taille d'une periode
              lineSpacing: 20,
              theta: 0.02, //vitesse
              periodOffset: 0,
              dotColor: "white",
              maxDotSize: 3,
              minDotSize: 0.1
          };
          this.curveOffset = 0;
          this.canvas = canvas;
          this.options = Object.assign(this.options, options);
          this.points = [];
          this.pointsZ = [];
      }

      init() {
          let canvasHeight = this.canvas.canvas.height;
          this.points = Array(Math.floor(canvasHeight / this.options.pointSpacing))
              .fill(0, 0, Math.floor(canvasHeight / this.options.pointSpacing) - 1);
          this.pointsZ = Array(Math.floor(canvasHeight / this.options.pointSpacing))
              .fill(0, 0, Math.floor(canvasHeight / this.options.pointSpacing) - 1);
      }

      update(){
          this.curveOffset += this.options.theta;
          let x = this.curveOffset;
          for(let i = 0; i < this.points.length; i++) {
              this.points[i] = Math.sin(x + this.options.periodOffset) * this.options.amplitude;  // Math.log(i / 50);
              this.pointsZ[i] = (Math.sin(x + this.options.periodOffset + Math.PI / 2) + 1 + this.options.minDotSize)/ 2;
              x += this.options.dx;
          }
          this.draw();
      }

      draw(){
          let canvasWidth = this.canvas.canvas.width;
          let ctx = this.canvas.ctx;

          ctx.fillStyle = this.options.dotColor;
          for (let i = 0; i < this.options.lineNumber; i++) {
              for (let n = 0; n < this.points.length; n++) {
                  ctx.beginPath();
                  ctx.ellipse(
                      (canvasWidth - (this.options.lineNumber * this.options.pointSpacing / 2)) / 2 + this.points[n] - i * 10,
                      n * this.options.lineSpacing - i * 10,
                      this.options.maxDotSize * this.pointsZ[n],
                      this.options.maxDotSize * this.pointsZ[n],
                      0,
                      0,
                      2 * Math.PI
                  );
                  ctx.closePath();
                  ctx.fill();
              }
          }
      }
  }


  let sineCanvas = new SineCanvas();

  sineCanvas.addChild(
      new SineWave({
          lineNumber: 1,
          amplitude: 55,
          theta: 0.035,
          maxDotSize: 2.5,
          minDotSize: 0.4
      }, sineCanvas)
  );

  sineCanvas.addChild(
      new SineWave({
          periodOffset: Math.PI,
          lineNumber: 1,
          amplitude: 55,
          theta: 0.035,
          maxDotSize: 2.5,
          minDotSize: 0.4
      }, sineCanvas)
  );

})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };

})

.controller('NewCtrl', function($scope) {
  var mat = [];
var cartas = [];
var posiciones = [];
var rand = 0;
var carta1 = 0;
var parejas = 8;


function llenarMemoria(){
  for(var i = 1; i < 9; i++){
    mat[i-1] = i;
  }
  for(var i = 1; i < 9; i++){
    mat[i+7] = i;
  }
}

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }
  return array;
}

function asignar(c){
  if(cartas.length < 2){
    cartas.push(mat[c-1]);
  }
  if(posiciones.length < 2){
    posiciones.push(c);
  }
  var element = document.getElementById(c);
  switch(mat[c-1]){
      case 1:
         if(element.classList.contains("carta")) {
             element.classList.toggle("A");

         }
      break;
      case 2:
        if(element.classList.contains("carta")) {
             element.classList.toggle("B");

         }
      break;
      case 3:
        if(element.classList.contains("carta")) {
             element.classList.toggle("C");
         }
      break;
      case 4:
        if(element.classList.contains("carta")) {
             element.classList.toggle("D");
         }
      break;
      case 5:
        if(element.classList.contains("carta")) {
             element.classList.toggle("E");
         }
      break;
      case 6:
        if(element.classList.contains("carta")) {
             element.classList.toggle("F")
         }
      break;
      case 7:
        if(element.classList.contains("carta")) {
             element.classList.toggle("G")
         }
      break;
      case 8:
        if(element.classList.contains("carta")) {
             element.classList.toggle("H")
         }
      break;
    }
}

function resetearCarta(){
  for(var i = 0; i < cartas.length; i++){
    var element = document.getElementById(posiciones[i]);
    switch(cartas[i]){
      case 1:
         if(element.classList.contains("carta")) {
             element.classList.toggle("A")
         }
      break;
      case 2:
        if(element.classList.contains("carta")) {
             element.classList.toggle("B")
         }
      break;
      case 3:
        if(element.classList.contains("carta")) {
             element.classList.toggle("C")
         }
      break;
      case 4:
        if(element.classList.contains("carta")) {
             element.classList.toggle("D")
         }
      break;
      case 5:
        if(element.classList.contains("carta")) {
             element.classList.toggle("E")
         }
      break;
      case 6:
        if(element.classList.contains("carta")) {
             element.classList.toggle("F")
         }
      break;
      case 7:
        if(element.classList.contains("carta")) {
             element.classList.toggle("G")
         }
      break;
      case 8:
        if(element.classList.contains("carta")) {
             element.classList.toggle("H")
         }
      break;
    }
  }
  cartas = [];
  posiciones = []
}

function cartasIguales(){
  for(var i = 0; i < cartas.length; i++){
    var element = document.getElementById(posiciones[i]);
    element.classList.add("par");
  }
   parejas --;
   ganador();
   cartas = [];
   posiciones = [];

}

function comparaCarta(){
  if(cartas.length == 2){
    if(cartas[0]!=cartas[1]){
      setTimeout(function(){ resetearCarta() }, 450);
    }
    else{
      cartasIguales();
    }
  }
}

function ganador(){
  if(parejas ==0){
    document.getElementById('win').style.display = "block";
    document.getElementById('win').innerHTML = "En Horabuena! has completado el juego";
  }
}

document.addEventListener("click", function(e) {
  if(e.target.classList.contains("carta")) {
    asignar(e.target.id);
    comparaCarta();

}})



llenarMemoria();
shuffle(mat);
console.log(mat);

  
})

;
